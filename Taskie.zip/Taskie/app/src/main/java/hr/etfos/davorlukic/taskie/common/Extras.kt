package hr.etfos.davorlukic.taskie.common

const val EXTRA_SCREEN_TYPE = "extra_screen_type"
const val EXTRA_TASK_ID = "extra_task_id"
